<?php 
// 配置 - 这些设置控制你网站的外观和细节。更多详情请查阅文档。

// 通用设置

// 网站的页面标题
define('title', '小熊的短链接网站'); 

// 网站的简短标题，用于页脚和某些子页面
define('shortTitle', '短链');

// 网站描述，显示在首页
define('description', 'A quick description on why your site is so fantastic, what it does and why people should definitely start using it. Oh, and how it's free.'); 

// 网站的 favicon 图标
define('favicon', '/frontend/assets/img/favicon.ico');

// 网站 Logo，显示在首页
define('logo', '/frontend/assets/img/logo-black.png');

// 启用 reCAPTCHA V3（人机验证）
// 强烈建议使用 reCAPTCHA V3 来防止垃圾信息。你可以从这里获取站点密钥和密钥：https://www.google.com/recaptcha/admin/create
define("enableRecaptcha", false);

// reCAPTCHA V3 站点密钥
define("recaptchaV3SiteKey", 'YOUR_SITE_KEY_HERE');

// reCAPTCHA V3 密钥
define("recaptchaV3SecretKey", 'YOUR_SECRET_KEY_HERE');

// 启用缩短链接的身份验证要求
// true = 只有已认证用户可以缩短链接，false = 任何人都可以缩短
// 默认值：false
define('requireAuth', false);

// 启用自定义 URL 字段
// true 或 false
define('enableCustomURL', true);

// 可选
// 设置要使用的主色调。默认：#007bff
// 以下是一些你可以尝试的其他颜色：
// #f44336: 红色, #9c27b0: 紫色, #00bcd4: 青色, #ff5722: 橙色
define('colour', '#007bff');

// 可选
// 设置要使用的背景图片
// 默认：picsum.photos 随机照片
// define('backgroundImage', 'https://picsum.photos/1920/1080');

// 页脚设置

// 这些是页脚中的链接。为每个新链接添加一个新条目。
// 数组遵循标题-链接结构：
// "标题" => "链接",
$footerLinks = [
    "About"   =>  "https://sleeky.flynntes.com/",
    "Contact" =>  "https://yourls.org/",
    "Legal"   =>  "https://yourls.org/",
    "Admin"   =>  "/admin"
];

?>
