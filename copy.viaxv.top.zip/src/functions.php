<?php
/**
 * 数据处理函数库
 * 作者：Hackerdallas
 */
if (!defined('ACCESS_ALLOWED')) exit('Access Denied');

// 读取数据
function loadData() {
    if (file_exists(DATA_FILE)) {
        $content = file_get_contents(DATA_FILE);
        return json_decode($content, true) ?: [];
    }
    return [];
}

// 保存数据
function saveData($data) {
    file_put_contents(DATA_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// 清理过期项目
function cleanExpired(&$data) {
    $now = time();
    $cleanedCount = 0;
    
    foreach ($data as $key => $item) {
        // 获取过期时间，默认0（永久保存）
        $expire = isset($item['expire']) ? intval($item['expire']) : 0;
        
        // 只清理明确设置过期的项目（expire > 0 且已过期）
        // expire = 0 表示永久保存，不应被清理
        if ($expire > 0 && $expire < $now) {
            // 检查项目类型
            if ($item['type'] === 'file' && isset($item['path'])) {
                $filepath = $item['path'];
                // 检查文件是否存在后再删除
                if (file_exists($filepath)) {
                    @unlink($filepath);
                }
            }
            unset($data[$key]);
            $cleanedCount++;
        }
    }
    
    // 只有当确实清理了项目时才保存数据
    if ($cleanedCount > 0) {
        $data = array_values($data);
        saveData($data);
    }
}

// 格式化文件大小
function formatSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}

// 格式化时间
function formatExpire($expire) {
    if ($expire === 0) return '永久';
    $diff = $expire - time();
    if ($diff < 0) return '已过期';
    if ($diff < 3600) return floor($diff / 60) . '分钟';
    if ($diff < 86400) return floor($diff / 3600) . '小时';
    return floor($diff / 86400) . '天';
}

// 格式化持续时间
function formatDuration($seconds) {
    if ($seconds === 0) return '永久';
    if ($seconds < 3600) return ($seconds / 60) . '分钟';
    if ($seconds < 86400) return ($seconds / 3600) . '小时';
    return ($seconds / 86400) . '天';
}

// 隐藏部分IP地址
function maskIP($ip) {
    $parts = explode('.', $ip);
    if (count($parts) === 4) {
        return $parts[0] . '.' . $parts[1] . '.***.***';
    }
    return $ip;
}
