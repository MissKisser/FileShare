# 拖拽上传功能技术方案

## 项目背景
为现有的文件上传与文本存储系统添加全页面级别的拖拽上传功能。

## 现有系统分析

### 技术栈
- 前端：原生HTML/CSS/JavaScript
- 后端：PHP
- 样式：赛博朋克风格

### 现有上传流程
1. 用户通过`<input type="file">`选择文件
2. 点击"上传文件"按钮提交表单
3. 通过AJAX(XHR)发送FormData到后端
4. 后端PHP处理上传，返回JSON响应
5. 前端显示进度和结果

## 功能需求

### 1. 全页面拖拽区域
- 整个网页作为拖拽目标区域
- 当文件被拖入时显示明显的视觉反馈
- 视觉反馈包括：半透明遮罩、边框高亮、图标提示

### 2. 多文件支持
- 支持同时拖入单个或多个文件
- 自动识别并解析文件信息：
  - 文件名
  - 文件大小
  - 文件类型(MIME type)
- 文件显示在准备上传的文件列表中

### 3. 文件预览功能
- 图片文件：显示缩略图预览
- 其他文件：显示对应文件类型图标
- 显示文件大小和文件名

### 4. 文件管理
- 允许移除列表中的特定文件
- 允许清空全部文件
- 显示文件选择的下拉菜单

### 5. 上传功能
- 点击上传按钮后立即开始上传
- 显示整体上传进度条
- 显示每个文件的上传状态和进度百分比

### 6. 文件类型验证
- 支持常见图片格式：jpg, jpeg, png, gif, webp, svg
- 支持文档格式：pdf, doc, docx, xls, xlsx, ppt, pptx, txt
- 支持压缩包：zip, rar, 7z, tar, gz
- 对不支持的文件类型给出明确提示

### 7. 文件大小限制
- 设置合理的文件大小限制（默认100MB）
- 超出限制时提醒用户

### 8. 错误处理
- 捕获网络错误
- 捕获服务器错误
- 显示友好的错误信息
- 提供重试选项

### 9. 成功提示
- 上传完成后显示成功提示
- 可点击查看已上传的文件
- 可继续上传更多文件

### 10. 动画效果
- 拖拽进入/离开的过渡动画
- 文件添加/移除的动画
- 进度条动画
- 成功/错误提示动画

## 技术实现方案

### 前端架构

#### DOM结构
```html
<!-- 拖拽遮罩层 -->
<div id="dragOverlay" class="drag-overlay hidden">
    <div class="drag-content">
        <div class="drag-icon">📂</div>
        <div class="drag-text">松开鼠标开始上传</div>
    </div>
</div>

<!-- 文件列表容器 -->
<div id="fileListContainer" class="file-list-container hidden">
    <div class="file-list-header">
        <span>准备上传的文件 (<span id="fileCount">0</span>)</span>
        <button id="clearAllBtn" class="btn-clear">清空全部</button>
    </div>
    <div id="fileList" class="file-list"></div>
    <div class="file-list-footer">
        <span id="totalSize">总计: 0 B</span>
    </div>
</div>
```

#### JavaScript模块设计
1. **拖拽状态管理**
   - 监听dragenter, dragover, dragleave, drop事件
   - 维护拖拽状态（是否正在拖拽）

2. **文件处理模块**
   - FileReader API读取文件信息
   - 生成缩略图（图片）或文件类型图标
   - 文件大小格式化
   - MIME类型验证

3. **文件队列管理**
   - 维护待上传文件数组
   - 添加/移除单个文件
   - 清空全部文件
   - 计算总大小

4. **上传模块**
   - 使用XMLHttpRequest进行上传
   - 单文件或多文件FormData提交
   - 进度计算和显示
   - 错误捕获和重试

### CSS样式设计

#### 拖拽遮罩
- 半透明深色背景
- 居中的上传图标和文字
- 边框发光效果
- 过渡动画

#### 文件列表
- 卡片式文件项
- 左侧缩略图/图标
- 中间文件名和大小
- 右侧移除按钮
- 悬停效果

#### 进度条
- 整体进度条
- 单文件进度
- 百分比显示
- 动画效果

### 后端兼容性
- 保持现有的PHP上传处理逻辑不变
- 前端自动同步表单中的"保存时长"选项

## 实施步骤

### Step 1: 修改 templates/main.php
- 添加拖拽遮罩层HTML
- 添加文件列表容器HTML
- 添加必要的ID和class

### Step 2: 修改 assets/css/style.css
- 添加拖拽遮罩样式
- 添加文件列表样式
- 添加各种状态和动画样式

### Step 3: 修改 assets/js/upload.js
- 添加拖拽事件监听
- 添加文件处理逻辑
- 添加文件预览生成
- 添加上传逻辑
- 添加错误处理和重试

## 文件类型映射表

| 文件类型 | 图标 | 颜色 |
|---------|------|------|
| 图片(jpg/png/gif/webp) | 🖼️ | #4CAF50 |
| 视频(mp4/avi/mov) | 🎬 | #9C27B0 |
| 音频(mp3/wav/ogg) | 🎵 | #2196F3 |
| 文档(pdf/doc/txt) | 📄 | #FF9800 |
| 表格(xls/xlsx) | 📊 | #4CAF50 |
| 演示(ppt/pptx) | 📽️ | #FF5722 |
| 压缩包(zip/rar/7z) | 📦 | #795548 |
| 代码(js/py/php) | 💻 | #607D8B |
| 其他 | 📁 | #9E9E9E |

## 配置参数

```javascript
const UPLOAD_CONFIG = {
    maxFileSize: 100 * 1024 * 1024,  // 100MB
    allowedTypes: [
        // 图片
        'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
        // 视频
        'video/mp4', 'video/webm', 'video/ogg',
        // 音频
        'audio/mpeg', 'audio/wav', 'audio/ogg',
        // 文档
        'application/pdf', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/plain', 'text/csv',
        // 压缩包
        'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed',
        'application/x-tar', 'application/gzip',
        // 代码
        'text/javascript', 'application/javascript', 'text/python', 'text/php'
    ],
    maxFiles: 20  // 最多同时上传文件数
};