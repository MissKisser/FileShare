<?php if (!defined('ACCESS_ALLOWED')) exit('Access Denied'); ?>
<!--
    主模板文件
    作者：Hackerdallas
-->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文件上传与文本存储系统</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/drag-upload.css">
</head>
<body>
    <!-- 拖拽上传遮罩层 -->
    <div id="dragOverlay" class="drag-overlay">
        <div class="drag-content">
            <div class="drag-icon">
                <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17,8 12,3 7,8"/>
                    <line x1="12" y1="3" x2="12" y2="15"/>
                </svg>
            </div>
            <div class="drag-text">松开鼠标开始上传</div>
            <div class="drag-hint">支持图片、文档、压缩包等文件</div>
        </div>
    </div>

    <!-- 拖拽文件列表面板 -->
    <div id="dragFilePanel" class="drag-file-panel">
        <div class="drag-file-header">
            <span class="drag-file-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14,2 14,8 20,8"/>
                </svg>
                准备上传的文件 (<span id="dragFileCount">0</span>)
            </span>
            <button type="button" id="clearAllFiles" class="btn-clear-all">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
                清空全部
            </button>
        </div>
        <div id="dragFileList" class="drag-file-list"></div>
        <div class="drag-file-footer">
            <span id="dragTotalSize" class="drag-total-size">总计: 0 B</span>
            <div class="drag-file-actions">
                <button type="button" id="cancelDragUpload" class="btn-cancel-upload">取消</button>
                <button type="button" id="startDragUpload" class="btn-start-upload">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="17,8 12,3 7,8"/>
                        <line x1="12" y1="3" x2="12" y2="15"/>
                    </svg>
                    开始上传
                </button>
            </div>
        </div>
    </div>

    <!-- 上传进度面板 -->
    <div id="uploadProgressPanel" class="upload-progress-panel">
        <div class="progress-panel-header">
            <span class="progress-title">正在上传...</span>
            <button type="button" id="cancelUpload" class="btn-cancel-upload">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
                取消
            </button>
        </div>
        <div class="progress-overall">
            <div class="progress-label">
                <span>整体进度</span>
                <span id="overallProgress">0%</span>
            </div>
            <div class="progress-bar-container">
                <div id="overallProgressBar" class="progress-bar-fill"></div>
            </div>
        </div>
        <div id="fileProgressList" class="file-progress-list"></div>
    </div>

    <!-- 成功提示面板 -->
    <div id="successPanel" class="success-panel">
        <div class="success-content">
            <div class="success-icon">
                <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="9,12 12,15 16,10"/>
                </svg>
            </div>
            <div class="success-title">上传成功!</div>
            <div id="successMessage" class="success-message"></div>
            <div class="success-actions">
                <button type="button" id="viewFilesBtn" class="btn-view-files">查看文件</button>
                <button type="button" id="continueUploadBtn" class="btn-continue-upload">继续上传</button>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="header">
            <h1>📦 文件上传与文本存储系统</h1>
            <p>简单、快速、安全的临时文件和文本存储</p>
        </div>
        
        <div class="content">
            <?php if (isset($message)): ?>
                <div class="message"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <!-- 栅格布局 -->
            <div class="grid-layout">
            
            <!-- 文件上传 - 赛博朋克风格 -->
            <div class="grid-card grid-card-cyber">
                <h2> 文件上传</h2>
                <form id="uploadForm" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>选择文件（可多选）</label>
                        <input type="file" name="files[]" id="fileInput" multiple required accept="*/*">
                    </div>
                    <div class="form-group">
                        <label>保存时长</label>
                        <select name="duration">
                            <option value="600">10分钟</option>
                            <option value="3600">1小时</option>
                            <option value="86400">1天</option>
                            <option value="0">永久</option>
                        </select>
                    </div>
                    
                    <!-- 文件列表展示区域 - 支持拖拽和手动选择 -->
                    <div id="selectedFilesContainer" class="selected-files-container" style="display: none;">
                        <div class="selected-files-header">
                            <span class="selected-files-title">待上传文件 (<span id="selectedFileCount">0</span>)</span>
                            <button type="button" id="clearSelectedFiles" class="btn-clear-selected">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="18" y1="6" x2="6" y2="18"/>
                                    <line x1="6" y1="6" x2="18" y2="18"/>
                                </svg>
                                清空
                            </button>
                        </div>
                        <div id="selectedFileList" class="selected-file-list"></div>
                        <div class="selected-files-footer">
                            <span id="selectedTotalSize" class="selected-total-size">总计: 0 B</span>
                        </div>
                    </div>
                    
                    <div id="progressContainer" style="display: none; margin-top: 20px;">
                        <div style="background: #f0f0f0; border-radius: 10px; overflow: hidden; height: 35px; position: relative;">
                            <div id="progressBar" style="width: 0%; height: 100%; background: linear-gradient(90deg, #4CAF50, #45a049); transition: width 0.3s ease;"></div>
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-weight: bold; color: #333; font-size: 14px; z-index: 1;">
                                <span id="progressText">0%</span>
                            </div>
                        </div>
                        <div id="statusText" style="text-align: center; margin-top: 12px; color: #888; font-size: 13px;">准备上传...</div>
                    </div>
                    
                    <button type="submit" id="uploadBtn">上传文件</button>
                </form>
            </div>
            
            <!-- 文本保存 - 赛博朋克风格 -->
            <div class="grid-card grid-card-cyber">
                <h2> 剪贴板</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>文本内容</label>
                        <textarea name="text" placeholder="在此输入或粘贴文本内容..." required></textarea>
                    </div>
                    <div class="form-group">
                        <label>保存时长</label>
                        <select name="text_duration">
                            <option value="600" selected>10分钟</option>
                            <option value="3600">1小时</option>
                            <option value="86400">1天</option>
                            <option value="0">永久</option>
                        </select>
                    </div>
                    <button type="submit">保存文本</button>
                </form>
            </div>
            
            <!-- 文件列表 - 赛博朋克风格 -->
            <div class="grid-card section-full grid-card-cyber">
                <h2> 文件与文本列表</h2>
                <div class="list">
                    <?php if (empty($data)): ?>
                        <div class="empty">暂无数据</div>
                    <?php else: ?>
                        <?php foreach ($data as $index => $item): ?>
                            <div class="item">
                                <div class="item-info">
                                    <div class="item-name">
                                        <?php if ($item['type'] === 'file'): ?>
                                            📄 <?php echo htmlspecialchars($item['name']); ?>
                                        <?php else: ?>
                                            📝 文本内容
                                        <?php endif; ?>
                                    </div>
                                    <div class="item-meta">
                                        <?php if ($item['type'] === 'file'): ?>
                                            大小: <?php echo formatSize($item['size']); ?> | 
                                        <?php endif; ?>
                                        上传时间: <?php echo date('Y-m-d H:i:s', $item['time']); ?> | 
                                        剩余时间: <?php echo formatExpire($item['expire']); ?>
                                        <?php if (isset($item['ip'])): ?>
                                                | 上传IP: <?php echo htmlspecialchars($item['ip']); ?>
                                            <?php endif; ?>
                                    </div>
                                    <?php if ($item['type'] === 'text'): ?>
                                        <div class="text-preview" id="preview-<?php echo $index; ?>">
                                            <pre><?php echo htmlspecialchars(mb_substr($item['content'], 0, 200)); ?><?php if (mb_strlen($item['content']) > 200) echo '...'; ?></pre>
                                        </div>
                                        <div class="text-full" id="full-<?php echo $index; ?>" style="display: none;">
                                            <pre><?php echo htmlspecialchars($item['content']); ?></pre>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="item-actions">
                                    <?php if ($item['type'] === 'file'): ?>
                                        <a href="?download=<?php echo $index; ?>" class="btn-small">下载</a>
                                    <?php else: ?>
                                        <button class="btn-small btn-view" data-index="<?php echo $index; ?>">查看</button>
                                        <button class="btn-small btn-copy" data-index="<?php echo $index; ?>">复制</button>
                                    <?php endif; ?>
                                    <a href="javascript:void(0)" class="btn-small btn-delete"
                                       data-delete-url="?delete=<?php echo $index; ?>">删除</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- 上传日志 - 赛博朋克风格 -->
            <div class="grid-card section-full grid-card-cyber">
                <h2> 上传日志（最近10条）</h2>
                <div class="log-container">
                    <?php if (empty($uploadLogs)): ?>
                        <div class="empty">暂无上传记录</div>
                    <?php else: ?>
                        <table class="log-table">
                            <thead>
                                <tr>
                                    <th>上传时间</th>
                                    <th>文件名</th>
                                    <th>文件大小</th>
                                    <th>上传IP</th>
                                    <th>保存时长</th>
                                    <th>过期时间</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($uploadLogs as $log): ?>
                                    <tr>
                                        <td><?php echo date('Y-m-d H:i:s', $log['upload_time']); ?></td>
                                        <td class="log-filename"><?php echo htmlspecialchars($log['filename']); ?></td>
                                        <td><?php echo formatSize($log['filesize']); ?></td>
                                        <td><?php echo htmlspecialchars($log['ip']); ?></td>
                                        <td><?php echo formatDuration($log['duration']); ?></td>
                                        <td>
                                            <?php 
                                            if ($log['expire_time'] === 0) {
                                                echo '永久';
                                            } else {
                                                echo date('Y-m-d H:i:s', $log['expire_time']);
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            </div><!-- 栅格布局结束 -->
        </div>
    </div>
    
    <!-- Vanta.js 3D背景效果 - 简化版 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@0.5.21/dist/vanta.net.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            if (window.VANTA) {
                window.VANTA.NET({
                    el: 'body',
                    mouseControls: true,
                    touchControls: true,
                    gyroControls: false,
                    minHeight: 200.00,
                    minWidth: 200.00,
                    scale: 1.00,
                    scaleMobile: 1.00,
                    // 简化配色 - 降低线条数量和密度
                    color: 0x9933ff,        // 柔和的紫色连接线
                    backgroundColor: 0x0a0012,  // 更深的近黑色背景
                    points: 8.00,           // 减少节点数量
                    maxDistance: 18.00,     // 缩短连线距离
                    spacing: 20.00,         // 增加节点间距
                    showDots: false         // 隐藏点状背景
                });
            }
        });
    </script>
    <script src="assets/js/upload.js?v=<?php echo time(); ?>"></script>
</body>
</html>