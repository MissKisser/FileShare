# 文件上传与文本存储系统

> 简单、快速、安全的临时文件与文本存储解决方案

## 目录

- [项目简介](#项目简介)
- [核心特性](#核心特性)
- [技术架构](#技术架构)
- [目录结构](#目录结构)
- [部署方法](#部署方法)
  - [Windows 环境](#windows-环境)
  - [Linux 环境](#linux-环境)
- [配置说明](#配置说明)
- [使用指南](#使用指南)
- [常见问题](#常见问题)
- [安全建议](#安全建议)
- [贡献指南](#贡献指南)
- [更新日志](#更新日志)
- [许可证](#许可证)

---

## 项目简介

本项目是一个基于 PHP 的轻量级文件上传与文本存储系统，专注于提供便捷的临时文件分享和文本剪贴板功能。系统采用原生 PHP 开发，无需复杂的数据库依赖，通过 JSON 文件存储元数据，部署简单快捷。

该系统适用于以下场景：

- 临时文件分享
- 剪贴板文本云端保存
- 跨设备文件传输
- 快速分享文本内容

---

## 核心特性

| 特性 | 说明 |
|------|------|
| 多文件上传 | 支持同时上传多个文件，单次上传无数量限制 |
| 大文件支持 | 最大支持 5GB 单文件上传 |
| 文本剪贴板 | 保存文本内容到云端，支持查看和一键复制 |
| 智能过期 | 可设置保存时长（10分钟/1小时/1天/永久） |
| 自动清理 | 过期文件自动删除，释放存储空间 |
| 上传日志 | 记录最近 500 条上传历史，包含上传者 IP |
| 进度显示 | 实时显示上传进度和预计剩余时间 |
| 响应式设计 | 完美适配桌面端和移动端设备 |
| 隐私保护 | 上传者 IP 地址自动部分隐藏 |

---

## 技术架构

### 后端技术

- **PHP 7.4+** - 核心后端语言
- **JSON** - 数据存储格式（无需数据库）
- **原生 HTTP** - 处理文件上传和下载请求

### 前端技术

- **HTML5** - 语义化页面结构
- **CSS3** - 现代化样式设计
- **JavaScript** - 原生 JS 实现交互逻辑
- **Gulp + Sass** - 前端构建工具链

---

## 目录结构

```
copy.viaxv.top/
├── index.php                 # 应用入口文件
├── index.html                # 默认页面（站点创建成功提示）
├── phpinfo.php               # PHP 信息查看页面
├── .htaccess                 # Apache 伪静态配置
├── .user.ini                 # PHP 运行时配置
│
├── assets/                   # 公共资源目录
│   ├── css/
│   │   └── style.css         # 主样式文件
│   └── js/
│       └── upload.js         # 上传交互脚本
│
├── frontend/                 # 前端配置目录
│   ├── config.php            # 前端配置文件
│   ├── functions.php         # 辅助函数
│   ├── header.php            # HTML 头部模板
│   ├── footer.php            # HTML 底部模板
│   ├── gulpfile.js           # Gulp 构建配置
│   ├── package.json          # NPM 依赖配置
│   └── assets/
│       ├── img/              # 图片资源
│       ├── sass/             # SCSS 源文件
│       └── svg/              # SVG 图标
│
├── src/                      # 核心代码目录
│   ├── config.php            # 后端配置
│   ├── functions.php         # 核心函数库
│   └── handlers.php          # 请求处理器
│
├── storage/                  # 数据存储目录
│   ├── data.json             # 文件/文本元数据存储
│   └── upload_log.json       # 上传日志记录
│
├── templates/                # 模板目录
│   └── main.php              # 主页面模板
│
└── uploads/                  # 上传文件存储目录
```

### 核心文件说明

| 文件 | 说明 |
|------|------|
| `index.php` | 应用入口，处理请求和加载数据 |
| `src/handlers.php` | 请求处理器，包含上传、下载、删除逻辑 |
| `src/functions.php` | 核心函数库，提供数据读写、格式化等功能 |
| `templates/main.php` | 主页面模板，渲染用户界面 |
| `assets/js/upload.js` | 前端交互脚本，处理上传进度和用户操作 |

---

## 配置说明

### PHP 配置

文件位置：`.user.ini`

```ini
upload_max_filesize = 5000M    ; 单文件最大上传大小
post_max_size = 5000M          ; POST 数据最大大小
max_execution_time = 6000      ; 脚本最大执行时间（秒）
memory_limit = 512M            ; 内存限制
```

---

### 目录权限

```
/uploads/    # 存储上传的文件，需要写入权限
/storage/    # 存储数据文件和日志，需要写入权限
```

---

## 使用指南

### 文件上传

1. 点击「选择文件」按钮，可单选或多选文件
2. 选择保存时长（10分钟/1小时/1天/永久）
3. 点击「上传文件」按钮
4. 观察上传进度条，完成后自动刷新页面
5. 在文件列表中查看和管理已上传的文件

### 文本保存

1. 在「文本内容」区域输入或粘贴文本
2. 选择保存时长
3. 点击「保存文本」按钮
4. 文本自动保存并显示在列表中

### 文件和文本管理

| 操作 | 说明 |
|------|------|
| 下载 | 点击文件旁的「下载」按钮下载文件 |
| 查看 | 点击文本旁的「查看」按钮展开完整内容 |
| 复制 | 点击文本旁的「复制」按钮一键复制到剪贴板 |
| 删除 | 点击「删除」按钮移除文件或文本 |

### 上传日志

页面底部显示最近 50 条上传记录，包含以下信息：

- 上传时间
- 文件名
- 文件大小
- 上传者 IP（部分隐藏，保护隐私）
- 保存时长
- 过期时间

---

## 部署方法

### Windows 环境

推荐使用小皮面板（phpStudy），这是 Windows 平台最流行的 PHP 集成环境。

#### 1. 安装小皮面板

从 [小皮面板官网](https://www.xp.cn/) 下载并安装。

#### 2. 添加站点

1. 打开小皮面板 → 点击「网站」→「添加站点」
2. 填写域名（如 `copy.viaxv.top`）或使用测试域名
3. 选择 PHP 版本（7.4 或 8.0+）
4. 点击「确定」

#### 3. 部署项目

1. 将项目文件复制到 `C:\phpstudy_pro\WWW\copy.viaxv.top`
2. 确保 `uploads` 和 `storage` 目录有写入权限

#### 4. 启动访问

1. 点击「启动」按钮启动 Apache + PHP
2. 访问 `http://copy.viaxv.top`

> **大文件设置**：如需上传大文件，在小皮面板「PHP 管理」中调整 `upload_max_filesize` 和 `post_max_size` 参数。

---

### Linux 环境

```bash
# 1. 上传项目文件到 Web 服务器根目录
scp -r . user@your-server:/var/www/html/

# 2. 设置目录权限
chmod -R 755 /var/www/html/
chmod -R 777 /var/www/html/uploads/
chmod -R 777 /var/www/html/storage/

# 3. 验证安装
# 访问 http://your-domain.com 确认页面正常显示
```

---

## 常见问题

### Q1: 上传文件大小受限怎么办？

检查 PHP 配置中的以下参数：

- `upload_max_filesize` - 单文件最大上传大小
- `post_max_size` - POST 数据最大大小
- `memory_limit` - 内存限制

项目默认设置为 5GB，如需调整请修改 `.user.ini` 文件。

### Q2: 上传失败怎么办？

1. 检查 `uploads/` 和 `storage/` 目录是否有写入权限
2. 查看 PHP 错误日志
3. 确认磁盘空间充足
4. 检查网络连接是否正常

### Q3: 如何清理过期文件？

系统会在每次页面加载时自动清理过期文件。如需手动清理，可直接删除 `uploads/` 目录中的文件或清空 `storage/data.json`。

### Q4: 如何查看上传者的真实 IP？

系统支持获取真实 IP，会依次检查以下 HTTP 头：

1. `HTTP_CLIENT_IP`
2. `HTTP_X_FORWARDED_FOR`
3. `HTTP_X_REAL_IP`
4. `REMOTE_ADDR`

### Q5: 如何启用 reCAPTCHA 验证？

1. 在 [Google reCAPTCHA](https://www.google.com/recaptcha/admin/create) 注册站点
2. 获取 Site Key 和 Secret Key
3. 修改 `frontend/config.php`：

```php
define("enableRecaptcha", true);
define("recaptchaV3SiteKey", 'YOUR_SITE_KEY');
define("recaptchaV3SecretKey", 'YOUR_SECRET_KEY');
```

### Q6: PHP 命令找不到怎么办？

确保 PHP 已添加到系统 PATH：

```powershell
# 检查 PATH
$env:Path -split ";"

# 添加到 PATH（管理员权限）
[Environment]::SetEnvironmentVariable(
    "Path",
    $env:Path + ";C:\php",
    "User"
)
```

### Q7: 端口被占用怎么办？

更换端口号或查找占用端口的进程：

```powershell
# 更换端口
php -S localhost:9000

# 查找占用端口的进程
netstat -ano | findstr :8000
taskkill /PID <进程ID> /F
```

---

## 安全建议

1. **定期备份** - 定期备份 `storage/` 目录中的数据文件
2. **限制权限** - 确保 Web 服务器用户对必要目录有最小权限
3. **监控日志** - 定期查看上传日志，发现异常及时处理
4. **启用 HTTPS** - 生产环境建议启用 HTTPS 加密传输
5. **IP 隐藏** - 上传者 IP 地址已自动部分隐藏以保护隐私
6. **访问控制** - 如有需要，可启用 `requireAuth` 配置要求登录

---

## 贡献指南

欢迎提交问题报告和功能请求。如需贡献代码，请遵循以下步骤：

1. Fork 本仓库
2. 创建特性分支：`git checkout -b feature/amazing-feature`
3. 提交更改：`git commit -m 'Add some amazing feature'`
4. 推送分支：`git push origin feature/amazing-feature`
5. 开启 Pull Request

---

## 更新日志

### v1.0.0

- 初始版本发布
- 支持文件上传和文本保存
- 基本的过期清理功能
- 上传日志记录
- 实时上传进度显示
- 响应式界面设计

---

## 许可证

本项目仅供学习交流使用。

---

**作者**：Hackerdallas  
**最后更新**：2026-03
